package com.livetvbd.app.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.livetvbd.app.data.model.Channel
import com.livetvbd.app.data.model.ChannelGroup
import com.livetvbd.app.utils.M3UParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class ChannelRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("LiveTV_Prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _channels = MutableStateFlow<List<Channel>>(emptyList())
    val channels: StateFlow<List<Channel>> = _channels

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    companion object {
        const val KEY_M3U_URL = "m3u_url"
        const val KEY_FAVORITES = "favorites"
        const val KEY_LAST_CHANNEL = "last_channel"
        const val DEFAULT_URL = "http://10.0.0.2/tv.m3u8"
    }

    fun getM3UUrl(): String = prefs.getString(KEY_M3U_URL, DEFAULT_URL) ?: DEFAULT_URL

    fun saveM3UUrl(url: String) {
        prefs.edit().putString(KEY_M3U_URL, url).apply()
    }

    fun getFavoriteIds(): Set<String> {
        val json = prefs.getString(KEY_FAVORITES, null) ?: return emptySet()
        return try {
            val type = object : TypeToken<Set<String>>() {}.type
            gson.fromJson(json, type)
        } catch (e: Exception) { emptySet() }
    }

    fun toggleFavorite(channelId: String): Boolean {
        val favs = getFavoriteIds().toMutableSet()
        val isFav = if (favs.contains(channelId)) {
            favs.remove(channelId)
            false
        } else {
            favs.add(channelId)
            true
        }
        prefs.edit().putString(KEY_FAVORITES, gson.toJson(favs)).apply()
        // Refresh channels list with updated favorites
        val updated = _channels.value.map { it.copy(isFavorite = favs.contains(it.id)) }
        _channels.value = updated
        return isFav
    }

    fun saveLastChannel(channel: Channel) {
        prefs.edit().putString(KEY_LAST_CHANNEL, gson.toJson(channel)).apply()
    }

    fun getLastChannel(): Channel? {
        val json = prefs.getString(KEY_LAST_CHANNEL, null) ?: return null
        return try { gson.fromJson(json, Channel::class.java) } catch (e: Exception) { null }
    }

    suspend fun loadChannels(url: String? = null) {
        _isLoading.value = true
        _error.value = null
        try {
            val targetUrl = url ?: getM3UUrl()
            if (url != null) saveM3UUrl(url)
            val parsed = M3UParser.parseFromUrl(targetUrl)
            val favIds = getFavoriteIds()
            _channels.value = parsed.map { it.copy(isFavorite = favIds.contains(it.id)) }
        } catch (e: Exception) {
            _error.value = "চ্যানেল লোড করতে সমস্যা হয়েছে: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }

    fun getGroups(): List<ChannelGroup> {
        val groups = mutableMapOf<String, ChannelGroup>()
        _channels.value.forEach { ch ->
            val key = ch.category.ifEmpty { "General" }
            groups.getOrPut(key) { ChannelGroup(key) }.channels.add(ch)
        }
        return groups.values.sortedBy { it.name }
    }

    fun getFavoriteChannels(): List<Channel> = _channels.value.filter { it.isFavorite }

    fun searchChannels(query: String): List<Channel> {
        if (query.isBlank()) return _channels.value
        return _channels.value.filter {
            it.name.contains(query, ignoreCase = true) ||
            it.category.contains(query, ignoreCase = true)
        }
    }
}
