# LiveTV BD — Android App (Mobile + TV)

## 📱 অ্যাপের বৈশিষ্ট্য

### Mobile ও Android TV উভয়ের জন্য:
- ✅ M3U/M3U8 playlist সাপোর্ট (আপনার `http://10.77.77.10/` থেকে)
- ✅ ExoPlayer দিয়ে HLS লাইভ স্ট্রিমিং
- ✅ চ্যানেল গ্রিড ভিউ (Mobile: 3 কলাম, TV: 5 কলাম)
- ✅ ক্যাটাগরি ফিল্টার (M3U-র group-title অনুযায়ী স্বয়ংক্রিয়)
- ✅ চ্যানেল সার্চ
- ✅ পছন্দের চ্যানেল (Favorites) সেভ করা
- ✅ প্লেয়ারে চ্যানেল পরিবর্তন (আগে/পরে বোতাম)
- ✅ Android TV রিমোট কন্ট্রোল সাপোর্ট (D-Pad navigation)
- ✅ Auto-retry যদি স্ট্রিম বন্ধ হয়
- ✅ Local network (HTTP) সাপোর্ট

---

## 🛠 সেটআপ করার নিয়ম

### ধাপ ১: Android Studio ইনস্টল করুন
1. https://developer.android.com/studio থেকে Android Studio ডাউনলোড করুন
2. ইনস্টল করুন (Windows/Mac/Linux সব সাপোর্ট করে)

### ধাপ ২: প্রোজেক্ট খুলুন
1. Android Studio চালু করুন
2. **File → Open** → `LiveTVApp` ফোল্ডার সিলেক্ট করুন
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন

### ধাপ ৩: M3U URL সেট করুন
`ChannelRepository.kt` ফাইলে এই লাইনটি খুঁজুন:
```kotlin
const val DEFAULT_URL = "http://10.77.77.10/playlist.m3u"
```
আপনার আসল M3U ফাইলের path দিয়ে পরিবর্তন করুন।
উদাহরণ: `http://10.77.77.10/live/playlist.m3u`

### ধাপ ৪: APK বিল্ড করুন

#### Debug APK (টেস্টিং এর জন্য):
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```

#### Release APK (ব্যবহারের জন্য):
```
Build → Generate Signed Bundle/APK → APK
```
Keystore তৈরি করুন এবং সাইন করুন।

---

## 📺 Android TV তে ইনস্টল করার নিয়ম

### ADB দিয়ে (WiFi):
```bash
# TV-র IP address বের করুন (Settings → Network → IP)
adb connect 192.168.x.x:5555
adb install -r app-debug.apk
```

### USB দিয়ে:
```bash
adb install -r app-debug.apk
```

---

## 📱 Android Mobile তে ইনস্টল:
1. APK ফাইলটি ফোনে কপি করুন
2. **Settings → Install unknown apps** চালু করুন
3. APK তে ট্যাপ করে ইনস্টল করুন

---

## 🎮 Android TV রিমোট কন্ট্রোল:

| বোতাম | কাজ |
|-------|-----|
| ↑ D-Pad | আগের চ্যানেল |
| ↓ D-Pad | পরের চ্যানেল |
| OK/Enter | Controls দেখান/লুকান |
| Back | পেছনে যান |
| Play/Pause | Play/Pause |

---

## ⚙️ M3U ফাইল ফরম্যাট (আপনার সার্ভারের জন্য)

আপনার `http://10.77.77.10/playlist.m3u` এই ফরম্যাটে থাকলে কাজ করবে:

```m3u
#EXTM3U
#EXTINF:-1 tvg-id="btv" tvg-name="BTV" tvg-logo="http://..." group-title="বাংলাদেশি",বাংলাদেশ টেলিভিশন
http://10.77.77.10/stream/btv/index.m3u8

#EXTINF:-1 tvg-id="atv" tvg-name="ATN Bangla" group-title="বিনোদন",ATN Bangla
http://10.77.77.10/stream/atn/index.m3u8
```

---

## 🔧 সমস্যা হলে

**চ্যানেল লোড না হলে:**
- M3U URL সঠিক কিনা চেক করুন Settings এ গিয়ে
- ফোন ও সার্ভার একই WiFi নেটওয়ার্কে আছে কিনা দেখুন

**ভিডিও না চললে:**
- Stream URL সরাসরি VLC তে টেস্ট করুন
- HLS (.m3u8) এবং RTMP উভয় সাপোর্ট আছে

---

## 📦 Dependencies

- ExoPlayer (Media3) - ভিডিও প্লেয়ার
- OkHttp - নেটওয়ার্ক রিকোয়েস্ট
- Glide - ছবি লোড
- Android Leanback - TV UI
- Material Components - Mobile UI

---

*LiveTV BD App — তৈরি করেছে Claude AI*
