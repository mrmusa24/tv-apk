package com.livetvbd.app.utils

import com.livetvbd.app.data.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object M3UParser {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun parseFromUrl(url: String): List<Channel> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()
            parseM3UContent(body)
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun parseM3UContent(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()
        var i = 0
        var channelIndex = 0

        while (i < lines.size) {
            val line = lines[i].trim()

            if (line.startsWith("#EXTINF:")) {
                val info = parseExtInf(line)
                // Next non-empty line should be the stream URL
                var urlLine = ""
                var j = i + 1
                while (j < lines.size) {
                    val nextLine = lines[j].trim()
                    if (nextLine.isNotEmpty() && !nextLine.startsWith("#")) {
                        urlLine = nextLine
                        i = j
                        break
                    }
                    j++
                }

                if (urlLine.isNotEmpty()) {
                    channels.add(
                        Channel(
                            id = "ch_${channelIndex++}",
                            name = info["name"] ?: "Channel $channelIndex",
                            streamUrl = urlLine,
                            logoUrl = info["tvg-logo"] ?: "",
                            category = info["group-title"] ?: "General",
                            groupTitle = info["group-title"] ?: "General",
                            tvgId = info["tvg-id"] ?: "",
                            tvgName = info["tvg-name"] ?: info["name"] ?: ""
                        )
                    )
                }
            }
            i++
        }
        return channels
    }

    private fun parseExtInf(line: String): Map<String, String> {
        val result = mutableMapOf<String, String>()

        // Extract channel name (after the last comma)
        val lastComma = line.lastIndexOf(',')
        if (lastComma != -1 && lastComma < line.length - 1) {
            result["name"] = line.substring(lastComma + 1).trim()
        }

        // Extract attributes using regex
        val attrPattern = Regex("""(\S+?)="([^"]*?)"""")
        attrPattern.findAll(line).forEach { match ->
            val key = match.groupValues[1].lowercase()
            val value = match.groupValues[2]
            result[key] = value
        }

        return result
    }
}
