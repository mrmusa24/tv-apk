package com.livetvbd.app.ui.player

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.livetvbd.app.R
import com.livetvbd.app.data.model.Channel
import com.livetvbd.app.databinding.ItemPlayerChannelBinding

class PlayerChannelAdapter(
    private val channels: List<Channel>,
    private val onSelect: (Channel) -> Unit
) : RecyclerView.Adapter<PlayerChannelAdapter.VH>() {

    private var selectedIndex = 0

    fun setSelected(index: Int) {
        val old = selectedIndex
        selectedIndex = index
        notifyItemChanged(old)
        notifyItemChanged(index)
    }

    inner class VH(val binding: ItemPlayerChannelBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(channel: Channel, index: Int) {
            binding.tvName.text = channel.name
            binding.tvCat.text = channel.category
            if (channel.logoUrl.isNotEmpty()) {
                Glide.with(binding.root.context).load(channel.logoUrl)
                    .placeholder(R.drawable.ic_channel_placeholder).into(binding.ivLogo)
            } else {
                binding.ivLogo.setImageResource(R.drawable.ic_channel_placeholder)
            }
            val ctx = binding.root.context
            binding.root.setBackgroundColor(
                if (index == selectedIndex) ContextCompat.getColor(ctx, R.color.player_selected)
                else ContextCompat.getColor(ctx, android.R.color.transparent)
            )
            binding.root.setOnClickListener { onSelect(channel) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPlayerChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(channels[position], position)
    override fun getItemCount() = channels.size
}
