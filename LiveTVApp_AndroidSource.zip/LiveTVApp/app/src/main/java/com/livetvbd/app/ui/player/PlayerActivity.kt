package com.livetvbd.app.ui.player

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import com.bumptech.glide.Glide
import com.livetvbd.app.R
import com.livetvbd.app.data.model.Channel
import com.livetvbd.app.databinding.ActivityPlayerBinding
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private var currentChannel: Channel? = null
    private var channelList: ArrayList<Channel> = arrayListOf()
    private var currentIndex = 0
    private val hideControlsHandler = Handler(Looper.getMainLooper())
    private val hideControlsRunnable = Runnable { hideControls() }

    companion object {
        const val EXTRA_CHANNEL = "extra_channel"
        const val EXTRA_CHANNEL_LIST = "extra_channel_list"
        const val CONTROLS_HIDE_DELAY = 4000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        @Suppress("UNCHECKED_CAST")
        channelList = intent.getSerializableExtra(EXTRA_CHANNEL_LIST) as? ArrayList<Channel> ?: arrayListOf()
        currentChannel = intent.getSerializableExtra(EXTRA_CHANNEL) as? Channel

        currentIndex = channelList.indexOfFirst { it.id == currentChannel?.id }.coerceAtLeast(0)

        setupPlayer()
        setupControls()
        setupChannelSidebar()
        playCurrentChannel()
    }

    private fun setupPlayer() {
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        player = ExoPlayer.Builder(this).build().also { exoPlayer ->
            binding.playerView.player = exoPlayer
            binding.playerView.useController = false // We use custom controls

            exoPlayer.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_BUFFERING -> {
                            binding.progressBuffering.visibility = View.VISIBLE
                            binding.ivPlayPause.setImageResource(R.drawable.ic_pause)
                        }
                        Player.STATE_READY -> {
                            binding.progressBuffering.visibility = View.GONE
                            binding.tvError.visibility = View.GONE
                        }
                        Player.STATE_ENDED -> {
                            // Live stream ended - try reconnect
                            playCurrentChannel()
                        }
                        else -> {}
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    binding.progressBuffering.visibility = View.GONE
                    binding.tvError.visibility = View.VISIBLE
                    binding.tvError.text = "স্ট্রিম লোড হচ্ছে না। পুনরায় চেষ্টা করুন..."
                    // Auto retry after 5 seconds
                    Handler(Looper.getMainLooper()).postDelayed({ playCurrentChannel() }, 5000)
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    binding.ivPlayPause.setImageResource(
                        if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                    )
                }
            })
        }
    }

    private fun setupControls() {
        binding.playerView.setOnClickListener { toggleControls() }

        binding.ivPlayPause.setOnClickListener {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
            resetHideTimer()
        }

        binding.ivPrevChannel.setOnClickListener {
            if (currentIndex > 0) {
                currentIndex--
                currentChannel = channelList[currentIndex]
                playCurrentChannel()
                updateChannelInfo()
            }
        }

        binding.ivNextChannel.setOnClickListener {
            if (currentIndex < channelList.size - 1) {
                currentIndex++
                currentChannel = channelList[currentIndex]
                playCurrentChannel()
                updateChannelInfo()
            }
        }

        binding.ivBack.setOnClickListener { finish() }

        binding.ivChannelList.setOnClickListener {
            val isSidebarVisible = binding.rvSidebarChannels.visibility == View.VISIBLE
            binding.rvSidebarChannels.visibility = if (isSidebarVisible) View.GONE else View.VISIBLE
        }

        binding.btnRetry.setOnClickListener {
            binding.tvError.visibility = View.GONE
            playCurrentChannel()
        }
    }

    private var sidebarAdapter: PlayerChannelAdapter? = null

    private fun setupChannelSidebar() {
        sidebarAdapter = PlayerChannelAdapter(channelList) { channel ->
            currentIndex = channelList.indexOf(channel)
            currentChannel = channel
            playCurrentChannel()
            updateChannelInfo()
            binding.rvSidebarChannels.visibility = View.GONE
        }
        binding.rvSidebarChannels.adapter = sidebarAdapter
    }

    private fun playCurrentChannel() {
        val channel = currentChannel ?: return
        binding.progressBuffering.visibility = View.VISIBLE
        binding.tvError.visibility = View.GONE

        val mediaItem = MediaItem.fromUri(channel.streamUrl)
        player?.apply {
            setMediaItem(mediaItem)
            prepare()
            play()
        }
        updateChannelInfo()
        resetHideTimer()
    }

    private fun updateChannelInfo() {
        val channel = currentChannel ?: return
        binding.tvChannelName.text = channel.name
        binding.tvChannelCategory.text = channel.category
        binding.tvChannelNumber.text = "${currentIndex + 1} / ${channelList.size}"
        if (channel.logoUrl.isNotEmpty()) {
            Glide.with(this).load(channel.logoUrl)
                .placeholder(R.drawable.ic_channel_placeholder)
                .into(binding.ivChannelLogo)
        } else {
            binding.ivChannelLogo.setImageResource(R.drawable.ic_channel_placeholder)
        }
        sidebarAdapter?.setSelected(currentIndex)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun toggleControls() {
        if (binding.controlsOverlay.visibility == View.VISIBLE) {
            hideControls()
        } else {
            showControls()
        }
    }

    private fun showControls() {
        binding.controlsOverlay.visibility = View.VISIBLE
        resetHideTimer()
    }

    private fun hideControls() {
        binding.controlsOverlay.visibility = View.GONE
    }

    private fun resetHideTimer() {
        hideControlsHandler.removeCallbacks(hideControlsRunnable)
        hideControlsHandler.postDelayed(hideControlsRunnable, CONTROLS_HIDE_DELAY)
        showControls()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> { if (currentIndex > 0) { currentIndex--; currentChannel = channelList[currentIndex]; playCurrentChannel() }; return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { if (currentIndex < channelList.size - 1) { currentIndex++; currentChannel = channelList[currentIndex]; playCurrentChannel() }; return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { toggleControls(); return true }
            KeyEvent.KEYCODE_BACK -> { finish(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { player?.let { if (it.isPlaying) it.pause() else it.play() }; return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onResume() {
        super.onResume()
        player?.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        hideControlsHandler.removeCallbacks(hideControlsRunnable)
        player?.release()
        player = null
    }
}
