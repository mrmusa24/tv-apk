package com.livetvbd.app.data.model

import java.io.Serializable

data class Channel(
    val id: String,
    val name: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val category: String = "General",
    val groupTitle: String = "",
    val tvgId: String = "",
    val tvgName: String = "",
    val isFavorite: Boolean = false
) : Serializable

data class ChannelGroup(
    val name: String,
    val channels: MutableList<Channel> = mutableListOf()
)
