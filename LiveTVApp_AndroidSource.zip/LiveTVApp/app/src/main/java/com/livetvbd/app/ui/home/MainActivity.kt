package com.livetvbd.app.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.chip.Chip
import com.livetvbd.app.LiveTVApp
import com.livetvbd.app.R
import com.livetvbd.app.data.model.Channel
import com.livetvbd.app.databinding.ActivityMainBinding
import com.livetvbd.app.ui.player.PlayerActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val repo = (application as LiveTVApp).repository
        viewModel = ViewModelProvider(this, MainViewModelFactory(repo))[MainViewModel::class.java]

        setupRecyclerView()
        setupObservers()

        // Open last channel if available
        viewModel.getLastChannel()?.let { lastCh ->
            // Optionally auto-play
        }
    }

    private fun setupRecyclerView() {
        adapter = ChannelAdapter(
            onChannelClick = { channel -> openPlayer(channel) },
            onFavoriteClick = { channel -> viewModel.toggleFavorite(channel.id) }
        )
        binding.rvChannels.layoutManager = GridLayoutManager(this, 3)
        binding.rvChannels.adapter = adapter
    }

    private fun setupObservers() {
        lifecycleScope.launch {
            viewModel.isLoading.collect { loading ->
                binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
                binding.rvChannels.visibility = if (loading) View.GONE else View.VISIBLE
            }
        }

        lifecycleScope.launch {
            viewModel.error.collect { error ->
                if (error != null) {
                    binding.tvError.visibility = View.VISIBLE
                    binding.tvError.text = error
                } else {
                    binding.tvError.visibility = View.GONE
                }
            }
        }

        lifecycleScope.launch {
            viewModel.displayedChannels.collect { channels ->
                adapter.submitList(channels)
                binding.tvChannelCount.text = "${channels.size} চ্যানেল"
                if (channels.isEmpty() && !viewModel.isLoading.value) {
                    binding.tvEmpty.visibility = View.VISIBLE
                } else {
                    binding.tvEmpty.visibility = View.GONE
                }
            }
        }

        lifecycleScope.launch {
            viewModel.groups.collect { groups ->
                setupCategoryChips(groups.map { it.name })
            }
        }
    }

    private fun setupCategoryChips(categories: List<String>) {
        binding.chipGroupCategories.removeAllViews()
        val allCategories = listOf("All", "পছন্দের") + categories
        allCategories.forEach { cat ->
            val chip = Chip(this).apply {
                text = cat
                isCheckable = true
                isChecked = cat == "All"
                setOnClickListener {
                    viewModel.setCategory(cat)
                    for (i in 0 until binding.chipGroupCategories.childCount) {
                        (binding.chipGroupCategories.getChildAt(i) as? Chip)?.isChecked = false
                    }
                    isChecked = true
                }
            }
            binding.chipGroupCategories.addView(chip)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.search(newText ?: "")
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                showSettingsDialog()
                true
            }
            R.id.action_refresh -> {
                viewModel.loadChannels()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showSettingsDialog() {
        val currentUrl = viewModel.getM3UUrl()
        val editText = android.widget.EditText(this).apply {
            setText(currentUrl)
            hint = "M3U URL লিখুন"
            setPadding(48, 24, 48, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("প্লেলিস্ট URL সেটিংস")
            .setView(editText)
            .setPositiveButton("লোড করুন") { _, _ ->
                val url = editText.text.toString().trim()
                if (url.isNotEmpty()) viewModel.loadChannels(url)
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun openPlayer(channel: Channel) {
        viewModel.saveLastChannel(channel)
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_CHANNEL, channel)
            putExtra(PlayerActivity.EXTRA_CHANNEL_LIST, ArrayList(viewModel.displayedChannels.value))
        }
        startActivity(intent)
    }
}
