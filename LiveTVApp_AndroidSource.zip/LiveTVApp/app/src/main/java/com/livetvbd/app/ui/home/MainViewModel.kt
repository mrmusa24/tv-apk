package com.livetvbd.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.livetvbd.app.data.model.Channel
import com.livetvbd.app.data.model.ChannelGroup
import com.livetvbd.app.data.repository.ChannelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val repository: ChannelRepository) : ViewModel() {

    val channels: StateFlow<List<Channel>> = repository.channels
    val isLoading: StateFlow<Boolean> = repository.isLoading
    val error: StateFlow<String?> = repository.error

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory

    private val _searchQuery = MutableStateFlow("")

    private val _displayedChannels = MutableStateFlow<List<Channel>>(emptyList())
    val displayedChannels: StateFlow<List<Channel>> = _displayedChannels

    private val _groups = MutableStateFlow<List<ChannelGroup>>(emptyList())
    val groups: StateFlow<List<ChannelGroup>> = _groups

    init {
        loadChannels()
        viewModelScope.launch {
            repository.channels.collect { updateDisplayed() }
        }
    }

    fun loadChannels(url: String? = null) {
        viewModelScope.launch {
            repository.loadChannels(url)
            _groups.value = repository.getGroups()
            updateDisplayed()
        }
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
        updateDisplayed()
    }

    fun search(query: String) {
        _searchQuery.value = query
        updateDisplayed()
    }

    private fun updateDisplayed() {
        val q = _searchQuery.value
        val cat = _selectedCategory.value
        var list = if (q.isNotBlank()) repository.searchChannels(q) else repository.channels.value
        if (cat != "All" && cat != "পছন্দের") {
            list = list.filter { it.category == cat }
        } else if (cat == "পছন্দের") {
            list = repository.getFavoriteChannels()
        }
        _displayedChannels.value = list
    }

    fun toggleFavorite(channelId: String) {
        repository.toggleFavorite(channelId)
        updateDisplayed()
    }

    fun getM3UUrl(): String = repository.getM3UUrl()
    fun saveLastChannel(channel: Channel) = repository.saveLastChannel(channel)
    fun getLastChannel(): Channel? = repository.getLastChannel()
}

class MainViewModelFactory(private val repository: ChannelRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return MainViewModel(repository) as T
    }
}
