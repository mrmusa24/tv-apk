package com.livetvbd.app

import android.app.Application
import com.livetvbd.app.data.repository.ChannelRepository

class LiveTVApp : Application() {
    lateinit var repository: ChannelRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = ChannelRepository(this)
    }

    companion object {
        lateinit var instance: LiveTVApp
            private set
    }

    init {
        instance = this
    }
}
