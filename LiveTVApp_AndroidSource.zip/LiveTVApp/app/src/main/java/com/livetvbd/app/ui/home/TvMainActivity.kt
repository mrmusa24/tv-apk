package com.livetvbd.app.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.livetvbd.app.LiveTVApp
import com.livetvbd.app.data.model.Channel
import com.livetvbd.app.databinding.ActivityTvMainBinding
import com.livetvbd.app.ui.player.PlayerActivity
import kotlinx.coroutines.launch

class TvMainActivity : FragmentActivity() {

    private lateinit var binding: ActivityTvMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        binding = ActivityTvMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val repo = (application as LiveTVApp).repository
        viewModel = ViewModelProvider(this, MainViewModelFactory(repo))[MainViewModel::class.java]

        adapter = ChannelAdapter(
            onChannelClick = { openPlayer(it) },
            onFavoriteClick = { viewModel.toggleFavorite(it.id) }
        )

        // TV: 5 columns grid
        binding.rvChannels.layoutManager = GridLayoutManager(this, 5)
        binding.rvChannels.adapter = adapter

        lifecycleScope.launch {
            viewModel.displayedChannels.collect { adapter.submitList(it) }
        }
    }

    private fun openPlayer(channel: Channel) {
        viewModel.saveLastChannel(channel)
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_CHANNEL, channel)
            putExtra(PlayerActivity.EXTRA_CHANNEL_LIST, ArrayList(viewModel.displayedChannels.value))
        }
        startActivity(intent)
    }
}
